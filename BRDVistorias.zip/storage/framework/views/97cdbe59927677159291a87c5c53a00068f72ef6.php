<?php $__env->startSection("titulo", "Sala Comercial"); ?>

<?php $__env->startSection("cadastro"); ?>
    <main>
        <div class="margem-cadastro">
            <div class="container">
                <div class="titulo-cadastro">
                    Cadastrar Sala Comercial
                </div>
                <form action="/salacomercial" method="POST">
                    <?php echo csrf_field(); ?>
                    <section class="grid-cadastro">
                        <div class="form-group">
                            <label for="identLoja">Identificação da Loja</label>
                            <input type="text" name="nome" id="identLoja" value="<?php echo e($salacomercial->nome); ?>" class="form-control <?php echo e(($errors->get('nome') != null) ? 'is-invalid' : ''); ?>">
                            <small class="text-danger"><?php echo e(utf8_encode($errors->first("nome"))); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="nomePropri">Nome Proprietario</label>
                            <input type="text" name="nomeproprietario" id="nomePropri" value="<?php echo e($salacomercial->nomeproprietario); ?>" class="form-control <?php echo e(($errors->get('nomeproprietario') != null) ? 'is-invalid' : ''); ?>">
                            <small class="text-danger"><?php echo e(utf8_encode($errors->first("nomeproprietario"))); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="cep">Cep</label>
                            <input type="text" name="cep" id="cep" value="<?php echo e($endereco->cep); ?>" class="form-control <?php echo e(($errors->get('cep') != null) ? 'is-invalid' : ''); ?>">
                            <small class="text-danger"><?php echo e(utf8_encode($errors->first("cep"))); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="rua">Rua</label>
                            <input type="text" name="rua" id="txtRua" value="<?php echo e($endereco->rua); ?>" class="form-control <?php echo e(($errors->get('rua') != null) ? 'is-invalid' : ''); ?>">
                            <small class="text-danger"><?php echo e(utf8_encode($errors->first("rua"))); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="numero">Numero</label>
                            <input type="text" name="numero" id="txtNumero" value="<?php echo e($endereco->numero); ?>" class="form-control <?php echo e(($errors->get('numero') != null) ? 'is-invalid' : ''); ?>">
                            <small class="text-danger"><?php echo e(utf8_encode($errors->first("numero"))); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="bairro">Bairro</label>
                            <input type="text" name="bairro" id="txtBairro" value="<?php echo e($endereco->bairro); ?>" class="form-control <?php echo e(($errors->get('bairro') != null) ? 'is-invalid' : ''); ?>">
                            <small class="text-danger"><?php echo e(utf8_encode($errors->first("bairro"))); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="cidade">Cidade</label>
                            <input type="text" name="cidade" id="txtCidade" value="<?php echo e($endereco->cidade); ?>" class="form-control <?php echo e(($errors->get('cidade') != null) ? 'is-invalid' : ''); ?>">
                            <small class="text-danger"><?php echo e(utf8_encode($errors->first("cidade"))); ?></small>
                        </div>
                        <div class="form-group">
                            <label for="estado">Estado</label>
                            <input type="text" name="estado" id="txtEstado" value="<?php echo e($endereco->estado); ?>" class="form-control <?php echo e(($errors->get('estado') != null) ? 'is-invalid' : ''); ?>">
                            <small class="text-danger"><?php echo e(utf8_encode($errors->first("estado"))); ?></small>
                        </div>
                        <div class="form-group subgrid-cadastro">
                            <div>
                                <input type="hidden" name="id" value="<?php echo e($salacomercial->id); ?>" />
                                <button type="submit" class="btn btn-warning botaosalvar form-control">Salvar</button>
                            </div>
                            <div>
                                <button type="button" class="btn btn-danger botaolimpar form-control">Limpar</button>
                            </div>
                        </div>
                    </section>
                </form>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('listagem'); ?>
<div class="margem-listagem">
    <div class="container">
        <div class="titulo-cadastro">
            Listagem Sala Comercial
        </div>
        <table class="table table-striped">
            <colgroup>
                <col width="100">
                <col width="100">
                <col width="200">
                <col width="50">
                <col width="150">
                <col width="100">
                <col width="60">
                <col width="100">
                <col width="20">
                <col width="20">
            </colgroup>
            <thead>
                <tr>
                    <th>Identificação Loja</th>
                    <th>Nome Propietario</th>
                    <th>Rua</th>
                    <th>Numero</th>
                    <th>Bairro</th>
                    <th>Cidade</th>
                    <th>Estado</th>
                    <th>Cep</th>
                    <th>Editar</th>
                    <th>Excluir</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $salascomerciais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salacomercial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($salacomercial->nome); ?></td>
                        <td><?php echo e($salacomercial->nomeproprietario); ?></td>
                        <td>
                            <?php $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($endereco->id == $salacomercial->endereco): ?>
                                    <?php echo e($endereco->rua); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($endereco->id == $salacomercial->endereco): ?>
                                    <?php echo e($endereco->numero); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        </td>	
                        <td>
                            <?php $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($endereco->id == $salacomercial->endereco): ?>
                                    <?php echo e($endereco->bairro); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td>
                            <?php $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($endereco->id == $salacomercial->endereco): ?>
                                    <?php echo e($endereco->cidade); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>		
                        <td>
                            <?php $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($endereco->id == $salacomercial->endereco): ?>
                                    <?php echo e($endereco->estado); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>	
                        <td>
                            <?php $__currentLoopData = $enderecos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $endereco): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($endereco->id == $salacomercial->endereco): ?>
                                    <?php echo e($endereco->cep); ?>

                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>	
                        <td>
                            <a  href="/salacomercial/<?php echo e($salacomercial->id); ?>/edit" class="btn text-dark">
                                <i class="fa fa-magic"></i>
                            </a>
                        </td>
                        <td>
                            <a href="/salacomercial/<?php echo e($salacomercial->id); ?>/delete" class="btn botaoexcluir">
                                <i class="fas fa-times"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Program Files\VertrigoServ\www\BRDVistorias\resources\views/salacomercial/index.blade.php ENDPATH**/ ?>