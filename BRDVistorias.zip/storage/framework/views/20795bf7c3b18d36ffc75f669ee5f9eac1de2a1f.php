<?php $__env->startSection("titulo", "Vistoria"); ?>
<main>
    <?php $__env->startSection('listagem'); ?>
    <div class="margem-vistoria">
        <div class="container">
            <div class="titulo-cadastro">
                Listagem de Vistoria
            </div>
            <div class="titulo-respostas">
                <?php $__currentLoopData = $salacomerciais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $vistorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($sala->id == $visto->salacomercial): ?>
                            <h1>
                                <span>Sala Comercial: </span>
                                <?php echo e($sala->nome); ?>

                            </h1>
                            <h2>
                                <span>Data: </span>
                                <?php echo e($visto->datavistoria); ?>

                            </h2>
                            <p>
                                <span>Comentario: </span>
                                <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($visto->id == $com->vistoria): ?>
                                        <?php echo e($com->comentario); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </p>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <table class="table table-striped">
                <colgroup>
                    <col width="800">
                    <col width="200">
                </colgroup>
                <thead>
                    <tr>
                        <th>Pergunta</th>
                        <th>Situação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $respostas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php $__currentLoopData = $perguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($resp->pergunta == $perg->id): ?>
                                        <?php echo e($perg->pergunta); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>	
                            <td>
                                <?php if($resp->situacao == true): ?>
                                    OK
                                <?php else: ?>
                                    N OK
                                <?php endif; ?>
                            </td>	
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="div-botao-voltar">
                <a href="/vistoria" class="btn btn-danger botaolimpar">Voltar</a>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
</main>
<?php echo $__env->make("layout.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\BRDVistorias\resources\views/resposta/index.blade.php ENDPATH**/ ?>