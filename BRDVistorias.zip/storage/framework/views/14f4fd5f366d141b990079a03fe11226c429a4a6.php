<?php $__env->startSection("titulo", "Perguntas"); ?>
<main>
    <?php $__env->startSection("cadastro"); ?>
        <div class="margem-perguntas">
            <div class="container">
                <div class="titulo-cadastro">
                    Cadastrar Perguntas
                </div>
                <form action="/pergunta" method="POST">
                    <?php echo csrf_field(); ?>
                    <section class="grid-perguntas">
                        <div class="form-group">
                            <label for="pergunta">Pergunta  (maximo 1000 caracteres)</label>
                            <textarea name="pergunta" rows="10" maxlength="1000" id="pergunta" value="<?php echo e($pergunta->pergunta); ?>" class="form-control <?php echo e(($errors->get('pergunta') != null) ? 'is-invalid' : ''); ?>"><?php echo e($pergunta->pergunta); ?></textarea>
                            <small class="text-danger"><?php echo e(utf8_encode($errors->first("pergunta"))); ?></small>
                        </div>
                        <div class="subgrid-perguntas">
                            <div>
                                <input type="hidden" name="id" value="<?php echo e($pergunta->id); ?>" />
                                <button type="submit" class="btn btn-warning botaosalvar form-control">Salvar</button>
                            </div>
                            <div>
                                <button type="button" class="btn btn-danger botaolimpar form-control">Limpar</button>
                            </div>
                        </div>
                    </section>
                </form>
            </div>
        </div>
    <?php $__env->stopSection(); ?>
</main>
<?php $__env->startSection('listagem'); ?>
    <div class="margem-listagem">
        <div class="container">
            <div class="titulo-cadastro">
                Listagem Perguntas
            </div>
            <table class="table table-striped">
                <colgroup>
                    <col width="760">
                    <col width="120">
                    <col width="120">
                </colgroup>
                <thead>
                    <tr>
                        <th>Pergunta</th>
                        <th>Editar</th>
                        <th>Excluir</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $perguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pergunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($pergunta->pergunta); ?></td>	
                            <td>
                                <a href="/pergunta/<?php echo e($pergunta->id); ?>/edit" class="btn text-dark">
                                    <i class="fa fa-magic"></i>
                                </a>
                            </td>
                            <td>
                                <a href="/pergunta/<?php echo e($pergunta->id); ?>/delete" class="btn botaoexcluir">
                                    <i class="fas fa-times"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\BRDVistorias\resources\views/pergunta/index.blade.php ENDPATH**/ ?>