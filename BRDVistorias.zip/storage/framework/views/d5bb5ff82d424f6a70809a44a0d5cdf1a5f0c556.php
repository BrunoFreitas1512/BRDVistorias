<?php $__env->startSection("titulo", "Vistorias"); ?>
<main>
    <?php $__env->startSection('listagem'); ?>
    <div class="margem-vistoria">
        <div class="container">
            <div class="titulo-cadastro">
                Listagem de Vistorias
            </div>
            <table class="table table-striped">
                <colgroup>
                    <col width="300">
                    <col width="300">
                    <col width="300">
                    <col width="100">
                </colgroup>
                <thead>
                    <tr>
                        <th>Sala Comercial</th>
                        <th>Comentario</th>
                        <th>Data Vistoria</th>
                        <th>Visualizar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $vistorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vistoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php $__currentLoopData = $salascomerciais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sala): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($vistoria->salacomercial == $sala->id): ?>
                                        <?php echo e($sala->nome); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>	
                            <td>
                                <?php $__currentLoopData = $comentarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($vistoria->id == $com->vistoria): ?>
                                        <?php echo e($com->comentario); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                            </td>	
                            <td><?php echo e($vistoria->datavistoria); ?></td>	
                            <td>
                                <a href="/resposta/<?php echo e($vistoria->id); ?>" class="btn btn-dark form-control">
                                    Visualizar
                                    <i class="fas fa-angle-right"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
</main>
<?php echo $__env->make("layout.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\php\www\BRDVistorias\resources\views/vistoria/index.blade.php ENDPATH**/ ?>