<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Vistoria extends Model
{
    protected $table = "vistoria";
}
