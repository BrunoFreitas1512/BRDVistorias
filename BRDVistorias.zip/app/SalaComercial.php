<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SalaComercial extends Model
{
    protected $table = "salacomercial";
}
